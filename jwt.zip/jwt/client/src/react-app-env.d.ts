
/// <reference types="react-scripts" />